package com.sparta.list;

import org.apache.commons.collections4.CollectionUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

public class MainList {
    public static void main(String[] args) {

        List<String> platformQA = new ArrayList(Arrays.asList("Inna", "Sasha", "Nastya", "Vesta", "Mitya"));

        List<String> futureAutoQA = new ArrayList(Arrays.asList("Artem", "Inna", "Sasha", "Nastya", "Varvara", "Marina", "Olga", "Lera"));

        System.out.println("Substract result is a List " + CollectionUtils.subtract(futureAutoQA, platformQA));
        System.out.println();
        System.out.println("Intersection result is a List " + CollectionUtils.intersection(futureAutoQA, platformQA));
        System.out.println();
        System.out.println("Union result is a List " + CollectionUtils.union(futureAutoQA, platformQA));
        System.out.println();
        System.out.println("Symmetric Differences with disjunction result is a List " + CollectionUtils.disjunction(futureAutoQA, platformQA));
        System.out.println();
        System.out.println("Symmetric Differences with Class is a List " + symmetricDifferences(futureAutoQA, platformQA));
    }

    public static List<String> symmetricDifferences(List<String> futureAutoQA, List<String> platformQA) {
        List<String> diffPlatformQA = new ArrayList();
        diffPlatformQA = (List<String>) CollectionUtils.subtract(futureAutoQA, platformQA);
        List<String> diffFutureAutoQA = new ArrayList();
        diffFutureAutoQA = (List<String>) CollectionUtils.subtract(platformQA, futureAutoQA);
        List<String> symmetric = new ArrayList();
        symmetric = (List<String>) CollectionUtils.union(diffFutureAutoQA,diffPlatformQA);
        return symmetric;
    }
}

