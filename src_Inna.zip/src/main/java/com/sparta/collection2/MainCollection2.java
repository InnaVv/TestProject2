package com.sparta.collection2;

import java.util.Arrays;

public class MainCollection2 {
    public static void main(String[] args) {
        String[] platformQA = {"Inna", "Sasha", "Nastya", "Vesta", "Mitya"};
        int length1 = platformQA.length;
        String[] futureAutoQA = {"Inna", "Sasha", "Nastya", "Varvara", "Marina", "Olga", "Lera"};
        int length2 = futureAutoQA.length;

        System.out.println();
        String[] intersection = intersection(platformQA, futureAutoQA, length1, length2);
//        String[] subtract = subtract(platformQA, futureAutoQA, length1, length2);
        String[] combine = combine(platformQA, futureAutoQA, length1, length2);
        System.out.println("Union (Результат объединения массивов): " + Arrays.toString(combine));

    }



    public static String[] intersection(String[] platformQA, String[] futureAutoQA, int length1, int length2) {

        System.out.println("Intersection (результат вычисления пересечения массивов): ");
        for (int i = 0; i < length1; i++) {
            for (int j = 0; j < length2; j++) {
                //If element is matched then print it
                if (platformQA[i] == futureAutoQA[j]) {
                    System.out.println(platformQA[j]);
                }
            }
        }
        return null;
    }
    public static String[] combine(String[] platformQA, String[] futureAutoQA, int length1, int length2) {
        int length = length1 + length2;
        String[] result = new String[length];
        System.arraycopy(platformQA, 0, result, 0, length1);
        System.arraycopy(futureAutoQA, 0, result, length1, length2);
        return result;
    }
//    public static String[] subtract(String[] platformQA, String[] futureAutoQA, int length1, int length2) {
//
//        System.out.println("Subtract (результат вычисления разности массивов): ");
//        for (int j = 0; j < length1; j++) {
//            for (int i = 0; i < length2; i++) {
//                //If element is matched then print it
//                if (platformQA[j] = futureAutoQA[i]) {
//                } else System.out.println(platformQA[i]);
//            }
//        }
//        return null;
//    }

}
