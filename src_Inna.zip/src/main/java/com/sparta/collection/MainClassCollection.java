package com.sparta.collection;

public class MainClassCollection {
    public static void main(String[] args) {
        String[] passngers = {"Inna", "Ira"};

        for (int i=0; i< passngers.length; i++){
            String pp = passngers[i];
            pp = "Darling " + pp;
            System.out.println((i+1) +" Hello, " + pp);
        }

        for (String pp: passngers){ //бежим по всем, аналог строк 7,8

            System.out.println("Hello, " + pp);
        }
        String[] pass2 = new String[5];//5 пустых ящиков
        pass2[0] = "Inna0";
        pass2[1] = "Inna1";
        pass2[2] = "Inna2";
        pass2[3] = "Inna3";
        pass2[4] = "Inna4";

        for(String pp2: pass2){
            System.out.println(pp2);
        }

//        System.out.println(passngers);
    }
}
