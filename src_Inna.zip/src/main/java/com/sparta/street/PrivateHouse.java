package com.sparta.street;

public class PrivateHouse extends House {

    public double calculateRent (double placeArea, int peopleRegistered, int flatAmount){

        double price1 = ((placeArea * 10) + (peopleRegistered * 100));
//        System.out.println("Price for PrivateHouse is " + price1);
        return price1;
    }
}


