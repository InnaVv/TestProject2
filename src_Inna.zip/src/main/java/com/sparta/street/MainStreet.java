package com.sparta.street;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainStreet {
    public static void main(String[] args) {

        double sum = 0;

//        System.out.println("Initial price is " + sum);

        PrivateHouse privateHouse1 = new PrivateHouse();
        sum += privateHouse1.calculateRent(25.6,2,3);
        BlockHouse blockHouse1 = new BlockHouse();
//        BlockHouse blockHouse1 = new BlockHouse(3,3,1);
        sum += blockHouse1.calculateRent(25.6,2,3);

        TownHouse townHouse1 = new TownHouse();
        TownHouse townHouse2 = new TownHouse();
        try {
        sum += townHouse1.calculateRent(25.6,2,2);
        sum += townHouse2.calculateRent(25.6,2,2);
        } catch (IllegalStateException xx) {
            System.out.println("Please check Flat Amount value for Town House");
        }


//        TownHouse townHouse3 = new TownHouse();
//        TownHouse townHouse4 = new TownHouse();
//        ArrayList<TownHouse> houses2 = new ArrayList<TownHouse>(townHouse3, townHouse4);
//        for(TownHouse xxx: houses2) {
//            sum += xxx.calculateRent(100,3,2);
//        }

        ArrayList<TownHouse> houses1 = new ArrayList<TownHouse>();
        houses1.add(new TownHouse());
        houses1.add(new TownHouse());
        houses1.add(new TownHouse());
        houses1.add(new TownHouse());
//        System.out.println(houses1.size());
        for(TownHouse xxx: houses1) {
            sum += xxx.calculateRent(100,3,2);
        }

        System.out.println("Finish price is " + sum);
    }
}
