package com.sparta.street;

public class TownHouse extends House {


    public double calculateRent (double placeArea, int peopleRegistered, int flatAmount) {
        if (flatAmount == 2) {
            double price1 = 2 * ((placeArea * 10) + (peopleRegistered * 100));
//            System.out.println("Price for TownHouse is " + price1);
            return price1;}
        else {
            throw new IllegalStateException ("TownHouse has only 2 flats, other option are invalid");
        }

    }
}
