package com.sparta.street;

public class BlockHouse extends House {
//    public BlockHouse(double placeArea, int peopleRegistered, int flatAmount) {
//        this.flatAmount=flatAmount;
//        this.peopleRegistered=peopleRegistered;
//        this.flatAmount=flatAmount;
//    }
//
//    double placeArea;
//    int peopleRegistered;
//    int flatAmount;
//
//    block
//    }
}
