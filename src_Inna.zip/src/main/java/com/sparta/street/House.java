package com.sparta.street;

public abstract class House {

    double placeArea;
    int peopleRegistered;
    int flatAmount;

    public double calculateRent(double placeArea, int peopleRegistered, int flatAmount) {
        double price1 = flatAmount * ((placeArea * 10) + (peopleRegistered * 100));
//        System.out.println("Price for House is " + price1);
        return price1;
    }
}
