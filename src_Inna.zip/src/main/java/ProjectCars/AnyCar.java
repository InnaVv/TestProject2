package ProjectCars;

public class AnyCar {

    String car;
    double engineSize;
    int wheelQuantity;
    double fuelQuantity;

//    public void goToCity(String gorod) {
//        System.out.println("Car goes to " + gorod);
//    }
//
//    public void changeFuel(double fuelQuantity) {
//        System.out.println("Initial Fuel quantity is " + fuelQuantity);
//        double fuelMinus = Math.random() * 100;
//        fuelQuantity = fuelQuantity - fuelMinus;
//        System.out.println("Fuel quantity after trip is " + fuelQuantity);
//    }

    public void goToCity(String gorod, double fuelQuantity) {
        System.out.println("Car goes to " + gorod);
        System.out.println("Initial Fuel quantity is " + fuelQuantity);
        double fuelMinus = Math.random() * 100;
        fuelQuantity = fuelQuantity - fuelMinus;
        System.out.println("Fuel quantity after trip is " + fuelQuantity);
        ;
    }


}
