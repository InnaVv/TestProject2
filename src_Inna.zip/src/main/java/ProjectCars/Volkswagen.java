package ProjectCars;

public class Volkswagen extends AnyCar {
    int sittingQuantity = 5;
//    double fuelQuantity = 77;

    public void sittingVolkswagen() {

        System.out.println("There are " + sittingQuantity + " in Volkswagen");
    }
}

