package ProjectCars;

public class Logistic {
    public static void main(String[] args) {

//        Track track = new Track();
//        track.goToCity("Minsk2", 100);
//      track.changeFuel(100);
        Volkswagen volkswagen = new Volkswagen();
        volkswagen.goToCity("Minsk3", 200);
//        Ferrari ferrari = new Ferrari();
//        ferrari.goToCity("Grodno",175);
        volkswagen.sittingVolkswagen();




    }
}
