package ProjectCars;

public class Ferrari extends AnyCar{

}
