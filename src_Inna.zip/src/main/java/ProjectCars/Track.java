package ProjectCars;

public class Track extends AnyCar {
    int gruz = 5000;
    double fuelQuantity = 100;
//    public void fuelMethod(fuelQuantity) {
//
//       changeFuel(fuelQuantity);
//    }
}


