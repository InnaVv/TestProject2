package Calculator;

public class Div {
    public void divParams(int xxx, int yyy) {
        if (yyy == 0) {
            System.out.println("Делить на ноль нельзя!");
        } else {
            float fxxx = (float) (xxx);
            float fyyy = (float) (yyy);
            float result = fxxx / fyyy;
            System.out.println(xxx + " / " + yyy + " = " + result);
        }
    }
}
