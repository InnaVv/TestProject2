package Calculator;

public class Subtr {
    public int subtrParams(int xxx, int yyy) {
        int result = xxx - yyy;
        System.out.println(xxx + " - " + yyy + " = " + result);
        return result;
    }
}
