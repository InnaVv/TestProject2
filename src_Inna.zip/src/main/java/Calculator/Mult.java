package Calculator;

public class Mult {
    public int multParams(int xxx, int yyy) {
        int result = xxx * yyy;
        System.out.println(xxx + " * " + yyy + " = " + result);
        return result;
    }
}
