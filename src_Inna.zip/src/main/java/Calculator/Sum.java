package Calculator;

public class Sum {
    public int sumParams(int xxx, int yyy) {
        int result = xxx + yyy;
//        System.out.println(xxx + " + " + yyy + " = " + result);
        return result;
    }

}
