package Calculator;

public class Calculator {
    public static void main(String[] args) {
        Sum sum = new Sum();
        Subtr subtr = new Subtr();
        Mult mult = new Mult();
        Div div = new Div();
        int xxx = 25;
        int yyy = 3;

        System.out.println(sum.sumParams(5, 9));
        subtr.subtrParams(10, 45);
        mult.multParams(7, 8);
        div.divParams(64, 3);
//        System.out.println(xxx + " + " + yyy + " = " + sum.result);

//        int xxx = 25;
//        int yyy = 3;
//        sum.sumParams(xxx,yyy);
//        subtr.subtrParams(xxx,yyy);
//        mult.multParams(xxx,yyy);
//        div.divParams(xxx,yyy);
    }
}
